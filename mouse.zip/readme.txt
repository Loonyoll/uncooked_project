﻿=== pixel cur Cursor Set ===

By: selever_pink

Download: http://www.rw-designer.com/cursor-set/pixel-cur

Author's description:

this cursor set was inspired by one already created as a modification for a game called terraria, so I enlarged this set and made it usable anywhere, enjoy it ;)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.